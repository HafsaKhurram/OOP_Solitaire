#include <iostream>
#include "HUMania.hpp"
#include "hearts.hpp"
#include "clubs.hpp"
#include "spades.hpp"
#include "diamonds.hpp"
#include "solitaire.hpp"

//hearts heart( 3,  1);
void HUMania::drawObjects()
{
    // call draw functions of all the objects here
    /*for (int i =0; i<Cols.size();i++){
        Cols[i].draw();
    }*/
    //heart.draw(100, 400);
    Solitaire.solitaire_draw();





}

int RandomGenerator(){
    int store = rand()%3;
    return store;
}

void HUMania::HU_quit(){
    //Cols.clear();

}

HUMania:: HUMania(){
    Solitaire = solitaire();
}

void HUMania::createObject(int x, int y)
{

    std::cout << "Mouse clicked at: " << x << " -- " << y << std::endl;
}
