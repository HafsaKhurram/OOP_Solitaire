#include<SDL.h>
#include "pigeon.hpp"
#include "bee.hpp"
#include "butterfly.hpp"
#include<vector>
#include "columns.hpp"
#include<list>
#include "solitaire.hpp"
#pragma once
using namespace std;

class HUMania{

    //Right now we're creating one pigeon, 
    //Pigeon p1(3,6);

    // In the solution you have to create vectors of pigeons, eggs, and nests    
    
    int modes;
    solitaire Solitaire;

    public:

    HUMania();

    void HU_quit();
    void drawObjects(); 
    void createObject(int x, int y);
    
};