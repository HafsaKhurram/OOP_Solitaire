#include "deck.cpp"
#include <iostream>
#include <random>
#include <algorithm>
#include <string>

using namespace std;
using std::cout;




