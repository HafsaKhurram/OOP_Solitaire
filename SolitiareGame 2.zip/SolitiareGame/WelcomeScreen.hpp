#include "timer.hpp"
#include "rules.hpp"
#include <iostream>
class WelcomeScreen {

    int icons = 3;
    //timer Timer;
    /*buttons Rules;
    buttons StartGame;*/
    






};