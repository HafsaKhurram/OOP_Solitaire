#include "bee.hpp"
// pigeon implementation will go here.
void Bee::draw(){
    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect, &moverRect);
}
//deletion is left 
void Bee::fly(){
    mover();
    if (moverRect.x >=1000){
        del = 1;
    }
    else{
        if (hover == 1){
            if (frame <10){
                hover =1;
                frame = frame+1;
            }
            else{
                hover = 0;
                frame =0;
            }
        }
        else{
        moverRect.x +=2;
        Hover();}
    }

}

void Bee::mover(){
    if (state==1){
        srcRect = {234,630,163,162};
        state =2;
    }
    else if (state == 2){
        srcRect={409,650,171,147};
        state =3;
    }
    else if (state == 3){
        srcRect={63,619,151,166};
        state =1;
    }


}
void Bee::Hover(){
    prob = rand()% 100;
    if (prob==1){
        hover =1;
    }
}
int Bee:: Deletion(){
    if (del==1){
        return 1;
    }
    else {
        return 0;
    }
}
Bee::Bee(int x, int y){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {63,619,151,166};
    state = 1;
    del= 0;
    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {x, y, 50, 50};
}