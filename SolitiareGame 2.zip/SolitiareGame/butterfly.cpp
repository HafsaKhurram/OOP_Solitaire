#include "butterfly.hpp"
#include "drawing.hpp"

void Butterfly::draw(){
    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect, &moverRect);
}
void Butterfly::mover(){
    if (state==1){
        srcRect = {257,182,192,214};
        state =2;
    }
    else if (state == 2){
        srcRect={248,433,247,178};
        state =3;
    }
    else if (state == 3){
        srcRect={256,24,174,134};
        state =1;
    }
}
void Butterfly::fly(){
    mover();
    Trajectory();
    if (moverRect.x == 1000){
        moverRect.x = 0;
    }
        moverRect.x = moverRect.x + 2;
        if (traj == 1){
            moverRect.y = moverRect.y -2;
        }
        if (traj == 0){
            moverRect.y = moverRect.y + 2;
        }

    // 
}
// 600 bottom and zero top 

void Butterfly::Trajectory(){
    if (moverRect.y>=600){
        traj = 1;
    }
    if (moverRect.y<=0){
        traj = 0;
    }
}

Butterfly::Butterfly(int x, int y){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {256,24,174,134};
    int state = 1;
    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {x, y, 50, 50};
    traj = 0;
}
