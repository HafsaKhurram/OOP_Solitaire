#include<SDL.h>
#include "drawing.hpp"
class Butterfly{

    SDL_Rect srcRect, moverRect;
    int frame = 0;
    int state;
    int traj;

public:
    // add the fly function here as well.
    void draw();
    void fly();
    void mover();
    void Trajectory();
    Butterfly(int x, int y); 
    // may add other overloaded constructors here... 
};