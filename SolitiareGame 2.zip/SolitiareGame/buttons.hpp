class buttons{

    int x;
    int y;

    

};