/*#include <iostream>
#include <vector>
#include "cards.cpp"

class Deck {
public: 
	Deck();
	void add(Card);
    void remove()
	void draw();
	int start_x;
	int start_y;
	int getsize() {return v.size();}
	vector<Card> v;
	void display();
	int position; //position of card in deck
	int show; //number of cards to display
    Card *Deck; //array of cards
    int top; //last element of deck
    int size; //number of cards in deck
	
private:
	int three;
};*/