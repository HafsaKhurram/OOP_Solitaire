#include "finaldeck.hpp"

finaldeck::finaldeck(string t){
    height = 0;
    complete = 0;
    type_of_card = t;

}

bool finaldeck::addcard(Cards card){
    if (typeid(card).name() == type_of_card){
        if (card.givenumber()==height+1){
            height = height +1;
            stack.push_back(card);
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
};

void finaldeck::drawdeck(int x, int y){

    if (height == 0){
        SDL_Rect moverRect = {x, y, 71,115};
        SDL_Rect r = {710,383,71,100};
        //SDL_Rect r = {639,383,71,100}; // trial
        SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &r, &moverRect);
    }
    else{
        stack[height-1].draw(x,y);
    }

}

void removecard(Cards card);

int finaldeck::iscomplete(){
    if (height == 13){
        complete = 1;
    }
    else{
        complete = 0;
    }
    return complete;
}