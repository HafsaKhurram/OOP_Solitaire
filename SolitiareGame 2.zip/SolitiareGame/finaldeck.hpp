#pragma once
#include<SDL.h>
#include "drawing.hpp"
#include "cards.hpp"
#include <vector>
#include<string>
#include <iostream>
#include<list>
using namespace std;

class finaldeck{

    private:
    int height;
    int complete;
    vector <Cards> stack;
    string type_of_card;

    public:

    finaldeck(string t);

    bool addcard(Cards card);

    void removecard(Cards card);

    void drawdeck(int x, int y);

    int iscomplete();

};