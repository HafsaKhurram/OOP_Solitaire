#include "pigeon.hpp"
// pigeon implementation will go here.

void Pigeon::draw(){
    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect, &moverRect);
}
void Pigeon::mover(){
    if (state==1){
        srcRect = {0,237,153,84};
        state =2;
    }
    else if (state == 2){
        srcRect={2,361,159,124};
        state =3;
    }
    else if (state == 3){
        srcRect={7,88,155,103};
        state =1;
    }
}
void Pigeon::fly(){
    mover();

    if (moverRect.x == 1000){
        moverRect.x = 0;
    }
    moverRect.x = moverRect.x + 2;

    // 
}

Pigeon::Pigeon(int x, int y){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {7,88,160,103};
    state = 1;
    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {x, y, 50, 50};
}

