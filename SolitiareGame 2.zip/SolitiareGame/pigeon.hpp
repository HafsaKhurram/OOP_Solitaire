#include<SDL.h>
#include "drawing.hpp"
class Pigeon{

    SDL_Rect srcRect, moverRect;
    int frame = 0;
    int state;

public:
    // add the fly function here as well.
    void draw();
    void fly();
    void mover();
    Pigeon(int x, int y); 
    // may add other overloaded constructors here... 
};
