#include<SDL.h>
#include "rules.hpp"
#include <string>

using namespace std;

void rules::draw_WINDOW(int x, int y){
  SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect_w, &moverRect_w);
}

void rules::draw_icon (int x, int y){
  SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect_i, &moverRect_i);
}