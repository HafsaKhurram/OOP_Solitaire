#pragma once
#include<SDL.h>
#include<vector>
#include "columns.hpp"
#include "cards.hpp"
#include "hearts.hpp"
#include "diamonds.hpp"
#include "spades.hpp"
#include "clubs.hpp"
//#include "deck.hpp"
#include "finaldeck.hpp"
#include<list>
using namespace std;
class solitaire {
    vector <columns> Cols;
    vector <Cards> starter;
    //Deck deck;
    vector <finaldeck> finals;


    
    public:

    solitaire();
    int RandomGenerator(int i);
    void game_start();
    void fill_starter();
    void solitaire_draw();
    void solitaire_quit();


    int random;
    int see;
};